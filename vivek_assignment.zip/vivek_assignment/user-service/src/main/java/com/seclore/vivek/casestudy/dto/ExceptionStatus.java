package com.seclore.vivek.casestudy.dto;

import lombok.Data;

@Data
public class ExceptionStatus {
    private boolean status;
    private String messageIfAny;
}
