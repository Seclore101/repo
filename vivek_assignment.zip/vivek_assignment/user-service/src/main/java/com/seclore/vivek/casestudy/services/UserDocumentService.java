package com.seclore.vivek.casestudy.services;

import com.seclore.vivek.casestudy.dto.UserDocumentDto;
import com.seclore.vivek.casestudy.entity.UserDocument;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;

public interface UserDocumentService {
    List<UserDocumentDto> findByUpdatedAtAfterAndStatus(LocalDateTime updatedAt, boolean isProcessed);
    void updateDocumentStatus(long documentId, String status);
}
