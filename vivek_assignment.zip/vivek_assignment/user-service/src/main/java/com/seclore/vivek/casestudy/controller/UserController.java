package com.seclore.vivek.casestudy.controller;

import com.seclore.vivek.casestudy.dto.UserRegistrationDto;
import com.seclore.vivek.casestudy.entity.User;
import com.seclore.vivek.casestudy.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/users")
public class UserController {
    @Autowired
    private UserService userService;

    //this api is to register user and it's documents
    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestPart("user") UserRegistrationDto userRegistrationDto,
                                       @RequestPart("documents") MultipartFile[] documents) {
        User user = userService.registerUser(userRegistrationDto.getName(), userRegistrationDto.getEmail(), documents);
        return new ResponseEntity<>(user, HttpStatus.CREATED);
    }

    //this api is used to get the status of user documents
    @GetMapping("/status/{userId}")
    public ResponseEntity<?> getDocumentStatus(@PathVariable Long userId){
        String resp = userService.getDocumentStatus(userId);
        return new ResponseEntity<>(resp,HttpStatus.OK);
    }

    //fetching status of list of users
    @PostMapping("/statuses")
    public ResponseEntity<?> getStatusesForUsers(@RequestBody List<Long> userIds) {
        Map<Long, String> statuses = userService.getDocumentStatuses(userIds);
        return new ResponseEntity<>(statuses, HttpStatus.OK);
    }
}
