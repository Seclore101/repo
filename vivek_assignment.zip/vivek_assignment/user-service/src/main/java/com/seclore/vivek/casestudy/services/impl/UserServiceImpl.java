package com.seclore.vivek.casestudy.services.impl;

import com.seclore.vivek.casestudy.entity.User;
import com.seclore.vivek.casestudy.entity.UserDocument;
import com.seclore.vivek.casestudy.exceptions.FileStorageException;
import com.seclore.vivek.casestudy.exceptions.UserAlreadyPresentException;
import com.seclore.vivek.casestudy.exceptions.UserNotFoundException;
import com.seclore.vivek.casestudy.repositories.UserDocumentRepository;
import com.seclore.vivek.casestudy.repositories.UserRepository;
import com.seclore.vivek.casestudy.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private UserDocumentRepository userDocumentRepository;
    @Override
    public User registerUser(String name, String email, MultipartFile[] documents) {
        User existingUser = userRepository.findByEmail(email);
        if (existingUser != null) {
            throw new UserAlreadyPresentException("User already present in the system!");
        }
        User user = new User();
        user.setName(name);
        user.setEmail(email);
        List<UserDocument> documentList = new ArrayList<>();
        for(MultipartFile file : documents){
            String docType = file.getOriginalFilename();
            String uniqueFileName = generateUniqueFileName(docType);
            String filePath = null;
            try {
                filePath = saveDocumentFile(uniqueFileName, file);
            } catch (IOException e) {
                throw new FileStorageException("Could not store file " + uniqueFileName + ". Please try again!", e);
            }
            UserDocument userDocument = new UserDocument();
            userDocument.setType(docType);
            userDocument.setFilePath(filePath);
            userDocument.setStatus("in_process");
            userDocument.setUser(user);
            userDocument.setUpdatedAt(LocalDateTime.now());
            documentList.add(userDocument);
        }
        user.setDocuments(documentList);
        return userRepository.save(user);
    }

    @Override
    public String getDocumentStatus(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new UserNotFoundException("User with ID " + userId + " not found"));
        return user.getDocuments().stream()
                .map(doc -> doc.getType() + ": " + doc.getStatus()) // Convert each document to a string with type and status
                .reduce((a, b) -> a + ", " + b) // Concatenate all strings with a comma separator
                .orElse("No documents found");
    }

    @Override
    public Map<Long, String> getDocumentStatuses(List<Long> userIds) {
        return userRepository.findAllById(userIds).stream()
                .collect(Collectors.toMap(
                        User::getId,
                        user -> user.getDocuments().stream()
                                .map(doc -> doc.getType() + ": " + doc.getStatus())
                                .reduce((a, b) -> a + ", " + b)
                                .orElse("No documents found")
                ));
    }

    private String generateUniqueFileName(String originalFileName) {
        String timestamp = String.valueOf(System.currentTimeMillis());
        String extension = originalFileName.substring(originalFileName.lastIndexOf("."));
        return originalFileName.replace(extension, "") + "_" + timestamp + extension;
    }

    private String saveDocumentFile(String fileName, MultipartFile file) throws IOException {
        Path storagePath = Paths.get("C:/Users/vivek.dhyani/Downloads/vivek_assignment/user-service/documents");
        if (!Files.exists(storagePath)) {
            Files.createDirectories(storagePath);
        }
        File file1 = new File(storagePath.toFile(), fileName);
        file.transferTo(file1);
        return file1.getAbsolutePath();
    }

}
