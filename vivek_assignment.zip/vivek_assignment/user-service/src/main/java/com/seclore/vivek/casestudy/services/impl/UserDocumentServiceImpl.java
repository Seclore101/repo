package com.seclore.vivek.casestudy.services.impl;

import com.seclore.vivek.casestudy.dto.UserDocumentDto;
import com.seclore.vivek.casestudy.entity.UserDocument;
import com.seclore.vivek.casestudy.repositories.UserDocumentRepository;
import com.seclore.vivek.casestudy.services.UserDocumentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserDocumentServiceImpl implements UserDocumentService {
    @Autowired
    private UserDocumentRepository userDocumentRepository;

    @Override
    public List<UserDocumentDto> findByUpdatedAtAfterAndStatus(LocalDateTime updatedAt, boolean isProcessed) {
        List<UserDocument> userDocuments = userDocumentRepository.findByUpdatedAtAfterAndIsProcessed(updatedAt, isProcessed);
        List<UserDocumentDto> customDtos = userDocuments.stream().map(userDocument -> {
            UserDocumentDto dto = new UserDocumentDto();
            dto.setId(userDocument.getId());
            dto.setType(userDocument.getType());
            dto.setFilePath(userDocument.getFilePath());
            dto.setStatus(userDocument.getStatus());
            dto.setUserName(userDocument.getUser() != null ? userDocument.getUser().getName() : null);
            dto.setUpdatedAt(userDocument.getUpdatedAt());
            dto.setUserId(userDocument.getUser() != null ? userDocument.getUser().getId() : 0);
            return dto;
        }).collect(Collectors.toList());
        return customDtos;
    }

    @Override
    public void updateDocumentStatus(long documentId, String status) {
        UserDocument document = userDocumentRepository.findById(documentId).orElse(null);
        if (document != null) {
            document.setStatus(status);
            document.setProcessed(true);
            userDocumentRepository.save(document);
        }
    }
}
