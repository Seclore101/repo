package com.seclore.vivek.casestudy.services;

import com.seclore.vivek.casestudy.entity.User;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

public interface UserService {
    User registerUser(String name, String email, MultipartFile[] documents);
    String getDocumentStatus(Long userId);
    Map<Long, String> getDocumentStatuses(List<Long> userIds);
}
