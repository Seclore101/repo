package com.seclore.vivek.casestudy.exceptions;

import lombok.experimental.StandardException;

@StandardException
public class UserNotFoundException extends RuntimeException{
}
