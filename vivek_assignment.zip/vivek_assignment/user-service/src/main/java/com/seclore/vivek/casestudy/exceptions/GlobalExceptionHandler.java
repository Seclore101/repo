package com.seclore.vivek.casestudy.exceptions;

import com.seclore.vivek.casestudy.dto.ExceptionStatus;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

@ControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(UserAlreadyPresentException.class)
    public ResponseEntity<ExceptionStatus> handleUserAlreadyPresentException(UserAlreadyPresentException ex) {
        ExceptionStatus status = new ExceptionStatus();
        status.setStatus(false);
        status.setMessageIfAny(ex.getMessage());
        return new ResponseEntity<>(status, HttpStatus.BAD_REQUEST);
    }
    @ExceptionHandler(UserNotFoundException.class)
    public ResponseEntity<ExceptionStatus> handleUserNotFoundException(UserNotFoundException ex){
        ExceptionStatus status = new ExceptionStatus();
        status.setStatus(false);
        status.setMessageIfAny(ex.getMessage());
        return new ResponseEntity<>(status, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(FileStorageException.class)
    @ResponseBody
    public ResponseEntity<String> handleFileStorageException(FileStorageException ex) {
        return ResponseEntity
                .status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(ex.getMessage());
    }
}
