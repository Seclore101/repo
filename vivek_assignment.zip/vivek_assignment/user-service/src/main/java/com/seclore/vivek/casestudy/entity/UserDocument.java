package com.seclore.vivek.casestudy.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "user_document")
@Getter
@Setter
public class UserDocument {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String type;
    @Column(name = "file_path")
    private String filePath;
    private String status;
    @ManyToOne
    @JoinColumn(name = "user_id")
    @JsonBackReference
    private User user;
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    private boolean isProcessed;
}
/*
CREATE TABLE user_document (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        type VARCHAR(255) NOT NULL,
file_path VARCHAR(255) NOT NULL,
status VARCHAR(50) NOT NULL,
user_id BIGINT,
FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);*/
/*

ALTER TABLE user_document
ADD COLUMN updated_at DATETIME;*/
/*

CREATE TABLE user_document (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        type VARCHAR(255) NOT NULL,
file_path VARCHAR(255) NOT NULL,
status VARCHAR(50) NOT NULL,
user_id BIGINT,
updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
is_processed BOOLEAN DEFAULT FALSE,
FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
*/

