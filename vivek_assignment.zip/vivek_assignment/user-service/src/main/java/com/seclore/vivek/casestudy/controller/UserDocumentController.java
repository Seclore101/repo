package com.seclore.vivek.casestudy.controller;

import com.seclore.vivek.casestudy.dto.UserDocumentDto;
import com.seclore.vivek.casestudy.entity.UserDocument;
import com.seclore.vivek.casestudy.services.UserDocumentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/users/documents")
public class UserDocumentController {

    @Autowired
    private UserDocumentService userDocumentService;

    @GetMapping
    public List<UserDocumentDto> getDocumentsUpdatedAfter(
            @RequestParam LocalDateTime updatedAt,
            @RequestParam boolean isProcessed) {
        return userDocumentService.findByUpdatedAtAfterAndStatus(updatedAt, isProcessed);
    }

    @PutMapping("/{documentId}/status/{status}")
    public void updateDocumentStatus(@PathVariable long documentId, @PathVariable String status) {
        userDocumentService.updateDocumentStatus(documentId, status);
    }
}
