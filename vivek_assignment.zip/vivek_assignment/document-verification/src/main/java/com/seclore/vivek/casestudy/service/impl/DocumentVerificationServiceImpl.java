package com.seclore.vivek.casestudy.service.impl;

import com.seclore.vivek.casestudy.dto.UserDocumentDto;
import com.seclore.vivek.casestudy.service.UserServiceClient;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.io.File;
import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.CompletableFuture;

@Service
public class DocumentVerificationServiceImpl {
    @Autowired
    private UserServiceClient userServiceClient;

    @Value("${tesseract.datapath}")
    private String TESSDATA_PATH;

    @Scheduled(fixedRate = 60000) // Every 60 seconds
    public void verifyDocuments() throws Exception {
        LocalDateTime sixtySecondsAgo = LocalDateTime.now().minusSeconds(60);
        List<UserDocumentDto> documentsToProcess = userServiceClient.getDocumentsUpdatedAfter(sixtySecondsAgo, false);
        if(!documentsToProcess.isEmpty()) {
            processDocumentsAsync(documentsToProcess);
        }
    }

    private boolean processDocument(UserDocumentDto document) throws Exception {
        if (document.getFilePath().endsWith(".pdf")) {
            String extractedData = extractTextFromPdf(document.getFilePath());
            System.out.println("extracted data : "+extractedData);
            return extractedData != null && extractedData.toUpperCase().contains(document.getUserName().toUpperCase());
        } else if (document.getFilePath().endsWith(".jpg") || document.getFilePath().endsWith(".png") || document.getFilePath().endsWith(".jpeg")) {
            String extractedData = extractTextFromImage(document.getFilePath());
            return extractedData != null && extractedData.toUpperCase().contains(document.getUserName().toUpperCase());
        }
        return false;
    }

    //for extracting text from image, used Tesseract api
    private String extractTextFromImage(String filePath) {
        File file = new File(filePath);
        validateFile(file);

        Tesseract tesseract = new Tesseract();
        tesseract.setDatapath(TESSDATA_PATH);
        try {
            String result = tesseract.doOCR(file);
            return result;
        } catch (TesseractException e) {
            e.printStackTrace();
        }
        return "";
    }

    //for extracting text from pdf, used apache pdfLoader api
    public String extractTextFromPdf(String filePath) throws Exception {
        File file = new File(filePath);
        PDDocument document = Loader.loadPDF(file);
        PDFTextStripper ts = new PDFTextStripper();
        return ts.getText(document);
    }

    private void validateFile(File file) {
        if (!file.exists()) {
            throw new IllegalArgumentException("File does not exist: " + file.getAbsolutePath());
        }
        if (!file.canRead()) {
            throw new IllegalArgumentException("File cannot be read: " + file.getAbsolutePath());
        }
    }

    @Async
    public CompletableFuture<Void> processDocumentsAsync(List<UserDocumentDto> documentsToProcess) {
        System.out.println("Running method in background");
        for (UserDocumentDto document : documentsToProcess) {
            try {
                boolean isApproved = processDocument(document);
                userServiceClient.updateDocumentStatus(document.getId(), isApproved ? "approved" : "rejected");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return CompletableFuture.completedFuture(null);
    }

}
