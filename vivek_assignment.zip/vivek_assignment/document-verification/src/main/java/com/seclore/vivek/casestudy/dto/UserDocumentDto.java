package com.seclore.vivek.casestudy.dto;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
public class UserDocumentDto {
    private long id;
    private String type;
    private String filePath;
    private String status;
    private String userName;
    private long userId;
    private LocalDateTime updatedAt;
}
