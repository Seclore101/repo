package com.seclore.vivek.casestudy.service;

import com.seclore.vivek.casestudy.dto.UserDocumentDto;
import org.springframework.data.domain.Pageable;

import java.time.LocalDateTime;
import java.util.List;

public interface UserServiceClient {
    List<UserDocumentDto> getDocumentsUpdatedAfter(LocalDateTime updatedAt, boolean isProcessed);
    void updateDocumentStatus(long documentId, String status);
}
