package com.seclore.vivek.casestudy.service.impl;

import com.seclore.vivek.casestudy.dto.UserDocumentDto;
import com.seclore.vivek.casestudy.service.UserServiceClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class UserServiceClientImpl implements UserServiceClient {

    @Value("${user.service.url}")
    private String userServiceUrl;

    @Autowired
    private RestTemplate restTemplate;

    @Override
    public List<UserDocumentDto> getDocumentsUpdatedAfter(LocalDateTime updatedAt, boolean isProcessed) {
        String url = String.format("%s/users/documents?updatedAt=%s&isProcessed=%s", userServiceUrl, updatedAt, isProcessed);
        System.out.println("Fetching documents with URL: " + url);
        ResponseEntity<List<UserDocumentDto>> response = restTemplate.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<List<UserDocumentDto>>() {}
        );
        List<UserDocumentDto> result = response.getBody();
        return result;
    }

    @Override
    public void updateDocumentStatus(long documentId, String status) {
        String url = String.format("%s/users/documents/%d/status/%s", userServiceUrl, documentId, status);
        restTemplate.put(url, null);
    }
}
