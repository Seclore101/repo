package com.seclore.vivek.casestudy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DocumentVerificationApplicationTests {

	@Test
	void contextLoads() {
	}

}
